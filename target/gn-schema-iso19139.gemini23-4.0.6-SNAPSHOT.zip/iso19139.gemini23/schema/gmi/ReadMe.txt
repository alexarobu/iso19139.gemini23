
Validated with XSV 2.10, Xerces J 2.7.1 and XML Spy 2009 (2009-03-02, IGN / France - Nicolas Lesage / Marcellin Prudham)


**************************

Package gmi from Eden repository (http://eden.ign.fr/xsd) 2008-06-26 full release of ISO/TC211 schemas modified as follows :

- spatialRepresentationInformation.xsd line3:
xmlns:gml="http://www.opengis.net/gml"
replaced by
xmlns:gml="http://www.opengis.net/gml/3.2"

- spatialRepresentationInformation.xsd line11:
namespace="http://www.opengis.net/gml"
replaced by
namespace="http://www.opengis.net/gml/3.2"

